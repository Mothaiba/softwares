numclusters <- scan("r_k.txt")
dataname <- "r_data.csv"
tst <- read.csv(dataname,header = TRUE)
# Set the seed for the random generator of R to be used by kmeans.
set.seed(42)
model <- kmeans(tst, numclusters, iter.max = 200, nstart = 20)
assignments <- model$cluster
centers <- model$centers
size <- model$size
iterations <- model$iter
write(assignments, "r_assignments.csv", sep="\n")
write(size, "r_sizes.csv", sep="\n")
