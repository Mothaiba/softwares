figure
data = readtable('data.csv');
filename = data.Properties.VariableNames(5);
filename = strrep(filename,'ddott','.');
filename = strrep(filename,'_','\_');
Size = data{1,4};
xaxis = data{1,1};
yaxis = char(data{1,2});
zaxis = char(data{1,3});
xaxis = strrep(xaxis,'_','\_');
yaxis = strrep(yaxis,'_','\_');
zaxis = strrep(zaxis,'_','\_');

data(1,:) = [];
RGBcolor = data{:,[4 5 6]};
scatter3(str2double(data{:,1}),str2double(data{:,2}), ...
	str2double(data{:,3}),Size,data{:,[4 5 6]},'filled')
title(filename);
xlabel(xaxis);
ylabel(yaxis);
zlabel(zaxis);
view(45,45);
rotate3d on;
